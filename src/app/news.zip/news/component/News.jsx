"use client"
import { useState, useEffect } from "react"
import { Clock, Calendar, Star, ChevronDown, ChevronUp, RefreshCw, Filter, Search } from "lucide-react"

// Sample JSON data
const sportsData = {
  "liveMatches": [
    {
      "id": "live-1",
      "league": "Premier League",
      "sport": "football",
      "date": "2024-03-15T19:00:00Z",
      "time": "19:00",
      "status": "live",
      "venue": "Emirates Stadium",
      "homeTeam": {
        "name": "Arsenal",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgGWWdlEfC4wxp4Wq_daIO3_DQ00Hw8d7IiA&s",
        "score": 2
      },
      "awayTeam": {
        "name": "Liverpool",
        "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgGWWdlEfC4wxp4Wq_daIO3_DQ00Hw8d7IiA&s",
        "score": 1
      },
      "highlights": [
        { "player": "Saka", "time": "45'", "event": "goal" },
        { "player": "Salah", "time": "60'", "event": "goal" },
        { "player": "Martinelli", "time": "85'", "event": "goal" }
      ]
    },
    {
      "id": "live-2",
      "league": "NBA",
      "sport": "basketball",
      "date": "2024-03-15T20:30:00Z",
      "time": "20:30",
      "status": "live",
      "venue": "Staples Center",
      "homeTeam": {
        "name": "Lakers",
        "logo": "/lakers.png",
        "score": 110
      },
      "awayTeam": {
        "name": "Celtics",
        "logo": "/celtics.png",
        "score": 105
      },
      "highlights": [
        { "player": "LeBron", "time": "Q1", "event": "score" },
        { "player": "Tatum", "time": "Q2", "event": "score" }
      ]
    }
  ],
  "upcomingMatches": [
    {
      "id": "upcoming-1",
      "league": "La Liga",
      "sport": "football",
      "date": "2024-03-16T15:00:00Z",
      "time": "15:00",
      "status": "upcoming",
      "venue": "Camp Nou",
      "homeTeam": {
        "name": "Barcelona",
        "logo": "/barcelona.png"
      },
      "awayTeam": {
        "name": "Real Madrid",
        "logo": "/realmadrid.png"
      }
    },
    {
      "id": "upcoming-2",
      "league": "Champions League",
      "sport": "football",
      "date": "2024-03-20T20:00:00Z",
      "time": "20:00",
      "status": "upcoming",
      "venue": "Allianz Arena",
      "homeTeam": {
        "name": "Bayern Munich",
        "logo": "/bayern.png"
      },
      "awayTeam": {
        "name": "PSG",
        "logo": "/psg.png"
      }
    }
  ],
  "recentMatches": [
    {
      "id": "recent-1",
      "league": "Serie A",
      "sport": "football",
      "date": "2024-03-14T21:45:00Z",
      "time": "21:45",
      "status": "finished",
      "venue": "San Siro",
      "homeTeam": {
        "name": "Milan",
        "logo": "/milan.png",
        "score": 1
      },
      "awayTeam": {
        "name": "Inter",
        "logo": "/inter.png",
        "score": 2
      },
      "highlights": [
        { "player": "Lautaro", "time": "25'", "event": "goal" },
        { "player": "Giroud", "time": "70'", "event": "goal" },
        { "player": "Lautaro", "time": "80'", "event": "goal" }
      ]
    },
    {
      "id": "recent-2",
      "league": "NFL",
      "sport": "american football",
      "date": "2024-02-11T18:30:00Z",
      "time": "18:30",
      "status": "finished",
      "venue": "Allegiant Stadium",
      "homeTeam": {
        "name": "Chiefs",
        "logo": "/chiefs.png",
        "score": 25
      },
      "awayTeam": {
        "name": "49ers",
        "logo": "/49ers.png",
        "score": 22
      },
      "highlights": [{ "player": "Mahomes", "time": "Q4", "event": "touchdown" }]
    }
  ],
  "news": [
    {
      "id": "news-1",
      "title": "Arsenal defeat Liverpool in thrilling Premier League clash",
      "summary": "Arsenal moved within two points of Premier League leaders Liverpool with a dramatic 3-1 victory at the Emirates Stadium.",
      "content": "Martin Odegaard's second-half strike proved decisive as Arsenal beat Liverpool 3-1 in a pulsating Premier League encounter at the Emirates Stadium. The Gunners took the lead through Bukayo Saka before Mohamed Salah equalized. Gabriel Martinelli's late goal sealed the win for Mikel Arteta's side.",
      "category": "football",
      "date": "2024-03-15T21:45:00Z",
      "author": "James Smith",
      "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgGWWdlEfC4wxp4Wq_daIO3_DQ00Hw8d7IiA&s",
      "tags": ["Premier League", "Arsenal", "Liverpool"]
    },
    {
      "id": "news-2",
      "title": "LeBron leads Lakers past Celtics in overtime thriller",
      "summary": "LeBron James scored 35 points as the Los Angeles Lakers defeated the Boston Celtics 120-115 in overtime.",
      "content": "LeBron James delivered a vintage performance with 35 points, 12 rebounds and 7 assists to lead the Los Angeles Lakers to a 120-115 overtime victory against the Boston Celtics. Jayson Tatum had 32 points for the Celtics in a losing effort.",
      "category": "basketball",
      "date": "2024-03-15T23:30:00Z",
      "author": "Sarah Johnson",
      "image": "/news/lakers-celtics.jpg",
      "tags": ["NBA", "Lakers", "Celtics"]
    },
    {
      "id": "news-3",
      "title": "Barcelona vs Real Madrid: El Clásico preview",
      "summary": "Everything you need to know ahead of Saturday's El Clásico between Barcelona and Real Madrid.",
      "content": "Barcelona host Real Madrid in what promises to be a thrilling El Clásico on Saturday evening. Both teams come into the match in good form, with Barcelona looking to close the gap on league leaders Madrid. Key battles include Lewandowski vs Rudiger and Gavi vs Valverde.",
      "category": "football",
      "date": "2024-03-16T10:00:00Z",
      "author": "Carlos Ruiz",
      "image": "/news/el-clasico.jpg",
      "tags": ["La Liga", "Barcelona", "Real Madrid"]
    },
    {
      "id": "news-4",
      "title": "Inter Milan edge AC Milan in derby della Madonnina",
      "summary": "Inter Milan defeated city rivals AC Milan 2-1 in a tightly contested Serie A derby.",
      "content": "Lautaro Martinez scored twice as Inter Milan beat AC Milan 2-1 in the derby della Madonnina at San Siro. Olivier Giroud pulled one back for Milan but Inter held on for a crucial victory that keeps them top of Serie A.",
      "category": "football",
      "date": "2024-03-14T23:15:00Z",
      "author": "Marco Bianchi",
      "image": "/news/milan-derby.jpg",
      "tags": ["Serie A", "Inter", "Milan"]
    }
  ]
}

export default function News() {
  const [activeCategory, setActiveCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedNews, setExpandedNews] = useState({})
  const [isLoading, setIsLoading] = useState(false)

  // Simulate loading
  useEffect(() => {
    setIsLoading(true)
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 800)
    return () => clearTimeout(timer)
  }, [activeCategory, searchQuery])

  const categories = [
    { id: "all", name: "All News" },
    { id: "football", name: "Football" },
    { id: "basketball", name: "Basketball" },
    { id: "tennis", name: "Tennis" },
    { id: "american football", name: "NFL" }
  ]

  const toggleNewsExpand = (newsId) => {
    setExpandedNews(prev => ({
      ...prev,
      [newsId]: !prev[newsId]
    }))
  }

  const filteredNews = sportsData.news.filter(news => {
    const matchesCategory = activeCategory === "all" || news.category === activeCategory
    const matchesSearch = news.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         news.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         news.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Hero Section */}
      <section className="pt-28 pb-16 bg-gradient-to-br from-gray-900 to-gray-800 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-500">
                Sports News
              </span>
            </h1>
            <p className="text-xl text-gray-300">
              Breaking news, match reports and expert analysis
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {/* Filters and Search */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              {/* Category Filter */}
              <div className="flex-1 overflow-x-auto">
                <div className="flex space-x-2 pb-2">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={`px-4 py-2 rounded-full font-medium whitespace-nowrap transition-all duration-300 ${
                        activeCategory === category.id
                          ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg"
                          : "bg-white text-gray-700 hover:bg-gray-100"
                      }`}
                    >
                      {category.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Search */}
              <div className="relative w-full md:w-64">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="text-gray-400" size={18} />
                </div>
                <input
                  type="text"
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* News Grid */}
          {isLoading ? (
            <div className="grid gap-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow-md p-6 animate-pulse h-48"></div>
              ))}
            </div>
          ) : filteredNews.length > 0 ? (
            <div className="grid gap-8">
              {filteredNews.map((newsItem) => (
                <div key={newsItem.id} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
                  <div className="md:flex">
                    {/* News Image */}
                    <div className="md:w-1/3 h-48 md:h-auto">
                      <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                        {/* Image placeholder - replace with actual image */}
                       <img src={newsItem.image} alt="hdhueu"/>
                      </div>
                    </div>
                    
                    {/* News Content */}
                    <div className="p-6 md:w-2/3">
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-sm font-medium bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full">
                          {newsItem.category}
                        </span>
                        <span className="text-sm text-gray-500">
                          {formatDate(newsItem.date)}
                        </span>
                      </div>
                      
                      <h2 className="text-xl lg:text-2xl font-bold text-gray-800 mb-3">{newsItem.title}</h2>
                      <p className="text-gray-600 mb-4">{newsItem.summary}</p>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex flex-wrap gap-2">
                          {newsItem.tags.slice(0, 3).map((tag, idx) => (
                            <span key={idx} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                        
                        <button
                          onClick={() => toggleNewsExpand(newsItem.id)}
                          className="text-emerald-600 hover:text-emerald-800 font-medium flex items-center"
                        >
                          {expandedNews[newsItem.id] ? (
                            <>
                              Read Less <ChevronUp className="ml-1" size={18} />
                            </>
                          ) : (
                            <>
                              Read More <ChevronDown className="ml-1" size={18} />
                            </>
                          )}
                        </button>
                      </div>
                      
                      {expandedNews[newsItem.id] && (
                        <div className="mt-4 pt-4 border-t border-gray-100">
                          <p className="text-gray-700 mb-4">{newsItem.content}</p>
                          <div className="text-sm text-gray-500">
                            By {newsItem.author}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md p-8 text-center">
              <p className="text-gray-600">No news found matching your criteria.</p>
            </div>
          )}

          {/* Match Highlights Section */}
          <div className="mt-16">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800 mb-6 flex items-center">
              <Clock className="mr-3 text-emerald-600" size={24} />
              Match Highlights
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...sportsData.liveMatches, ...sportsData.recentMatches].slice(0, 4).map((match) => (
                <div key={match.id} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
                  <div className="p-4 bg-gray-800 text-white">
                    <div className="flex justify-between items-center">
                      <h3 className="font-bold">{match.league}</h3>
                      <span className={`text-sm px-2 py-1 rounded-full ${
                        match.status === 'live' ? 'bg-red-500' : 
                        match.status === 'upcoming' ? 'bg-blue-500' : 'bg-gray-500'
                      }`}>
                        {match.status === 'live' ? 'LIVE' : 
                         match.status === 'upcoming' ? 'UPCOMING' : 'COMPLETED'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-300">{match.venue}</p>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex justify-between items-center mb-4">
                      <div className="text-center">
                        <div className="w-12 h-12 bg-gray-200 rounded-full mx-auto mb-2 flex items-center justify-center">
                          {/* Team logo placeholder */}
                          <span className="text-xs">T1</span>
                        </div>
                        <span className="font-medium">{match.homeTeam.name}</span>
                        {match.homeTeam.score !== undefined && (
                          <span className="block text-xl font-bold">{match.homeTeam.score}</span>
                        )}
                      </div>
                      
                      <div className="text-gray-500 font-bold">VS</div>
                      
                      <div className="text-center">
                        <div className="w-12 h-12 bg-gray-200 rounded-full mx-auto mb-2 flex items-center justify-center">
                          {/* Team logo placeholder */}
                          <span className="text-xs">T2</span>
                        </div>
                        <span className="font-medium">{match.awayTeam.name}</span>
                        {match.awayTeam.score !== undefined && (
                          <span className="block text-xl font-bold">{match.awayTeam.score}</span>
                        )}
                      </div>
                    </div>
                    
                    {match.highlights && match.highlights.length > 0 && (
                      <div className="text-sm">
                        <h4 className="font-medium mb-2">Key Moments:</h4>
                        <ul className="space-y-1">
                          {match.highlights.slice(0, 2).map((hl, idx) => (
                            <li key={idx} className="flex items-center">
                              <span className="w-12 text-gray-500">{hl.time}</span>
                              <span className="flex-1">
                                {hl.event === 'goal' ? '⚽ Goal' : 
                                 hl.event === 'score' ? '🏀 Score' : 
                                 hl.event === 'touchdown' ? '🏈 Touchdown' : '🟨 Yellow card'}
                                {hl.player && ` by ${hl.player}`}
                              </span>
                            </li>
                          ))}
                        </ul>
                        {match.highlights.length > 2 && (
                          <button className="text-emerald-600 text-xs mt-2">
                            +{match.highlights.length - 2} more events
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}