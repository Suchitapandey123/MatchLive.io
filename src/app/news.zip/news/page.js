import React from 'react'

import News from './component/News'


const page = () => {
  return (
    <>
    <News/>
    </>
  )
}



export default News